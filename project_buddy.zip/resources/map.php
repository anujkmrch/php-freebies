<?php
	/**
	* Application Mapper Array
	* Infomration must be used to hook up application information to system class.
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

	$map['site'] = array('id' => 0,'path'=>SITE);
	$map['admin'] = array('id' => 1,'path'=>ADMIN);
	$map['app'] = array('id' => 2,'path'=>APP);
?>
<?php
	/**
	* Loader class to load class from resources
	* Simple autoloader to include defined classes
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/
class Loader{	
	
	/**
	* function to load system classes, can be use to loaded forcefully load
	* library or vendor folder, enabled with loading system or vendor library
	*
	* @class: class name to be loaded
	* @library: system library or vendor folder
	*
	*/
	function classes($class,$vendor= false){
		static $register;
		if(!isset($register)){
			$register = array();
		}
		$class = strtolower($class);
		if(!isset($register[$class])){
			$path = LIBRARY.DS.$class.'.class.php';
			$register[$class] = false;
			if(!file_exists($path)){
				$path = VENDOR.DS.$class.'.php';
			}
			if(file_exists($path))
			{
				$register[$class] = $path;
				include_once($path);
			}

		}
	}
}
function __autoload($class){
	Loader::classes($class);
}
?>
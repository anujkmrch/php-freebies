<?php


	/**
	* Configuration Array
	* Infomration must be used to hook up application configuration from central class
	* Central class uses factory design pattern to load centralize information
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

	$config['session_handler'] = 'database';

	//database driver and port
	$config['database_host'] = 'localhost';
	$config['database_user'] = 'root';
	$config['database_pass'] = '';
	$config['database_name'] = 'databasename';
	$config['database_port'] = '3306';
	$config['database_driver'] = 'dbdriver';


?>
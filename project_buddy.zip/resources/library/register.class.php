<?php
	/**
	* Custom Register to save custom values
	* We are using configuration to load it's value
	
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/
class Register{
	static $register;
	//initialize the namespace// required action.
	function initialize($namespace){
		if(!isset(self::$register)){
			self::$register = array();
		}
		if(!isset(self::$register[$namespace])){
			self::$register[$namespace] = array();
		}
	}
	
	//load the stored associative array in namespace.
	function load($options,$namespace){
		if(!is_array($options) or !is_object($options)){
			$options = (array) $options;
		}
		self::$register[$namespace] = $options;
		return true;
		//return false;
	}

	// Get the stored key from namespace, 
	// you must pass the what you will get after no value found
	// So you would not break the application for some reason
	function get($key,$default = null,$namespace){
		if(array_key_exists($key,self::$register[$namespace])){
			$return = self::$register[$namespace][$key];
			return $return;
		}
		return $default;
	}
}
?>
<?php
/**
	* Centralize loader class to load the system wide requirement
	* Such as configration file or current user.
	* 
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

class Central{
	
	/**
	* function to load system wide configuration or read
	* 
	* @class: class name to be loaded
	* @library: system library or vendor folder
	*
	*/
	function Config($key,$default = null){
		static $config;
		if(!isset($config)){
			Register::initialize('config');
			if(!file_exists(CONFIG_FILE)){
				die("System Configuration Error");
			}
			include_once(CONFIG_FILE);
			Register::load($config,'config');
			$config = true;
		}
		return Register::get($key,$default,'config');
	}

	function database(){
	}
}
?>
<?php
/**
	* Base "View" Class for Model View Controller Design Pattern
	* find and render the view layout file
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

class View{
	//mvc name
	var $name;

	//vars to stored in view
	var $vars = array();
	
	//can you guess what it is doing?
	function __construct($name){
		$this->name = $name;
	}
	
	//if you have read about php array, especially associative array, the it is doing the same.
	function set($key,$value){
		$this->vars[$key] = $value;
	}

	//render the layout file
	function render($file){
		$path = MVC_PATH.DS.$this->name.DS.'views'.DS.$file.'.php';
		if(!file_exists($path)){
			die("view template file does not exists for path: ".$path);
		}
		extract($this->vars);
		ob_start();
		include($path);
		$content = ob_get_contents();
		ob_get_clean();
		return $content;
	}
}
?>
<?php
	/**
	* Base "Controller" Class for Model View Controller Design Pattern
	* Responsible for loading view and model for desired controller and 
	* execute the action requested in url
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/
	
class Controller {
	var $name;
	var $map;
	function __construct($name){
		$this->name = $name;
		$class = (get_class_methods(__CLASS__));
		$object = (get_class_methods($this));
		$this->map = array_diff($object,$class);

	}

	//method to load model for mvc
	//please pass the model name
	function &getModel($model){
		static $instance;
		if(!isset($instance)):
			$return = null;
			$path = MVC_PATH.DS.$this->name.DS.'models'.DS.$model.'.php';
			if(!file_exists($path)){
				die("error: model file `{$model}` does not exists");
			}
			include_once($path);
			$class = ucfirst($this->name).ucfirst($model).'Model';
			if(!class_exists($class,false)){
				die("error: model class `{$class}`  does not exists");
			}
			$instance = new $class($this->name);
		endif;
		return $instance;
	}

	//method to load view class for desired controller
	function &getView(){
		static $instance;
		if(!isset($instance)):
			$return = null;
			$path = MVC_PATH.DS.$this->name.DS.'view.php';
			if(!file_exists($path)){
				die("error: view does not exists");
			}
			include_once($path);
			$class = ucfirst($this->name).'View';
			if(!class_exists($class,false)){
				die("error: view class does not exists");
			}
			$instance = new $class($this->name);
		endif;
		return $instance;
	}

	// method to execute from controller
	function execute($action,$params = array()){
		if(!in_array($action,$this->map)){
			die("error in executing the action");
		}
		return call_user_func(array($this,$action),$params);
	}
}
?>
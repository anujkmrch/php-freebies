<?php
	/**
	* Session Class to store the session and you will be able to store it in database or in file
	* Default is file, but you can use database as well
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

class Session{
	static $configured = false;
	static $handler = 'file';
	function configure(){
		//check session is configured or not if not configure it
		if(!self::$configured){
			session_name(CLIENT);
			self::$handler = Central::Config('session_handler','file');
			self::setHandle();
			self::$configured = true;
		}
	}

	function setHandle(){
		$handler = 'Handler_'.self::$handler;
		call_user_func(array(__CLASS__,$handler));
	}

	function Handler_file(){
		return;
	}

	function Handler_database(){
		session_set_save_handler(
			array(__CLASS__,'db_open'),
			array(__CLASS__,'db_close'),
			array(__CLASS__,'db_read'),
			array(__CLASS__,'db_write'),
			array(__CLASS__,'db_destroy'),
			array(__CLASS__,'db_gc')
		);
		return;
	}
	
	function start(){
		if(!self::$configured){
			self::configure();
		}
		session_start();
	}

	function regenerate(){
		session_regenerate_id();
	}

	function destroy(){
		unset($_SESSION);
		session_destroy();
		self::start();
	}

	function getData($namespace){
		if(!isset($_SESSION[$namespace])){
			return null;
		}
		return $_SESSION[$namespace];
	}
	
	function clearNamespace($namespace){
		if(array_key_exists($namespace,$_SESSION))
			$_SESSION[$namespace] = array();
		return true;
	}

	function get($key, $default = null,$namespace){
		if(!isset($_SESSION[$namespace]) or !array_key_exists($key, $_SESSION[$namespace])){
			return null;
		}
		return $_SESSION[$namespace][$key];
	}

	function set($key, $value,$namespace='_default'){
		$old = null;
		if(!isset($_SESSION[$namespace])){
			$_SESSION[$namespace] = array();
		}
		if(!is_null($value)){
			if(array_key_exists($key, $_SESSION[$namespace])){
				$old = $_SESSION[$namespace][$key];
			}
			$_SESSION[$namespace][$key] = $value;
		} else{
			unset($_SESSION[$namespace][$key]);
		}
		return $old;
	}

	function db_open($path, $name) {
		return true;
	}

	function db_close() {

	}

	function db_read($sessionId) {
		//query to be used for your database system
		 $sql = "SELECT session_data FROM session where session_id = '$sessionId'";
		 return array();
	}

	function db_write($sessionId, $data) {
		$sql = "INSERT INTO session SET session_id ='$sessionId', session_data ='$data' ON DUPLICATE KEY UPDATE session_data ='$data'";
		//query to be used for your database system
		return true;
	}
	
	function db_destroy($sessionId) {
		 $sql = "DELETE FROM session WHERE session_id =" . $db->quote($sessionId); 
		 //query to be used for your database system
	}

	function db_gc($lifetime=null) {
		$sql = "DELETE FROM session WHERE session_lastaccesstime < DATE_SUB(NOW(), INTERVAL " . $lifetime . " SECOND)";
		//query to be used for your database system
	}
}
?>
<?php
/**
	* Centralize System Class
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

class System{
	static $name = CLIENT;
	static $id = null;
	static $path = null;

	function settings($setting){
		self::$id = isset($setting['id']) ? $setting['id'] : null;
		self::$path = isset($setting['path']) ? $setting['path'] : null;
	}

	function start(){
		// to initialize database Connection
		Central::database();
		//to start session and to configure it
		Session::configure();
		//start session for the first time
		Session::start();
	}

	function execute($options){
		if(!isset($options['controller']) or empty($options['controller']) ){
			die("error: Can't find controller - ".__CLASS__);
		}
		
		if(!isset($options['action']) or empty($options['action']) ){
			$options['action'] = "index";
		}
		
		define('MVC_PATH',self::$path.DS.'mvc');
	
		$path = MVC_PATH.DS.$options['controller'].DS.$options['controller'].'.php';
		if(!file_exists($path)){
			die("error: MVC FILE DOES NOT EXISTS - ".__CLASS__);	
		}
		
		$content = '';
		ob_start();
		include_once($path);
		$content = ob_get_contents();
		ob_end_clean();

		return $content;
	}
}
?>
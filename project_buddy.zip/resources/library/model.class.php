<?php
/**
	* Base "Model" Class for Model View Controller Design Pattern
	* Almost empty but having mvc name also
	*
		* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

class Model{
	var $name;
	function __construct($name){
		$this->name = $name;
	}
	//I suppose you will use this method to load multiple rows
	function findAll(){ return null; }
 
 	//I suppose you will use this method to use single row
	function find(){ return null; }

	//delete method to use save one row
	function delete(){ return null; }
	
	//update method
	function update(){return null; }
}
?>
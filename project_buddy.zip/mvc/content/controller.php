<?php
	class ContentController extends Controller{
		function __construct(){
			parent::__construct('content');
		}

		function index(){
			if(!($view = $this->getView())){
				die("hllo ".__CLASS__);
			}
			$model = $this->getModel('content');

			$contents = $model->findAll();
			$view->set('content',$contents);
			return $view->render('index');
		}

		function show(){

		}
	}

?>
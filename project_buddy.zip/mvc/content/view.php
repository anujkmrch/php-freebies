<?php
	class ContentView extends View{

	}
?>
<?php
	include_once("controller.php");
	$content = new contentController();
	echo $content->execute($options['action']);
?>
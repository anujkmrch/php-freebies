<?php
class ContentContentModel extends Model{
	function findAll(){
		$return = array();
		//use this sql query if you are looking to make this thing happen
		$sql = "SELECT * FROM articles";
		return $return;
	}

	function find($id){
		echo $id;
	}
}
?>
<?php
	/**
	* Calling Page: Directory Index Page in terms of Apache Server
	*
	* @package    project_buddy
	* @author     Anuj Kumar Chaudhary {https://facebook.com/anujkch}
	* @version    0.1.0
	*/

	define('DS',DIRECTORY_SEPARATOR);

	//define which client it is
	define('CLIENT','site');

	//system classes file
	define('RESOURCES',dirname(__FILE__).DS.'resources');
	define('LIBRARY',RESOURCES.DS.'library');
	define('VENDOR',RESOURCES.DS.'vendor');

	//mapper and configuration file path
	define('MAPPER_FILE',RESOURCES.DS.'map.php');
	define('CONFIG_FILE',RESOURCES.DS.'config.php');

	//theme path
	define('THEMES',dirname(__FILE__).DS.'themes');
	define('WIDGETS',dirname(__FILE__).DS.'widgets');


	//client path 
	define('SITE',dirname(__FILE__));
	define('ADMIN',dirname(__FILE__).DS.'admin');
	define('APP',dirname(__FILE__).DS.'app');

	//load the resource loader
	require_once(RESOURCES.DS.'loader.php');


	//intialise with register with config namespace, however not required but recommended
	Register::initialize('config');
	//good idea to initialize the default route, else your application broke

	// Well I recommend you to go for the request mapping

	//path to exclude we don't want
  	$request  = str_replace("/path/to/exclude", "", $_SERVER['REQUEST_URI']);
	$parts = parse_url($request);

	$settings = array();

	//load the client settings into system for client wide configuration
	System::settings($settings);

	//initialize the basic system call
	System::start();

	//well this is something wondeful thing to execute the system system file	
	$content = System::execute($route);

	//till here you are having your system output so you can have it
	//it is your time to render the things. You can use static php code
	//or you can use some template engine, why don't you try twig or smarty or roll your own


	//for the sake you start developing some stuff, we are printing the output here
	echo $content;
?>